/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


/**
 *
 * @author LABSIS
 */
public class Operaciones {
     //suma
    public Resultado Suma(double a, double b){
        double resultadoSuma = a + b;
        Resultado result = new Resultado(resultadoSuma, true, "Suma realizada correctamente");
        return result;
    }
    
    //resta
    public Resultado Resta(double minuendo, double sustraendo){
        double resultadoResta = minuendo - sustraendo;
        Resultado result = new Resultado(resultadoResta, true, "Resta realizada correctamente");
        return result;
    }
    
    //multiplicacion
    public Resultado Multiplicacion(double factor1, double factor2){
        double resultadoMultiplicacion = factor1 * factor2;
        Resultado result = new Resultado(resultadoMultiplicacion, true, "Multiplicacion realizada correctamente");
        return result;
    }
    
    //division
    public Resultado Division(double dividendo, double divisor){
        if(divisor ==0){
            Resultado result = new Resultado(0, false, "No es posible dividir por cero");
            return result;
        }
        double resultadoDivision= dividendo/divisor;
        Resultado result = new Resultado(resultadoDivision, true, "Division realizada correctamente");
        return result;
    }
    
    //procentaje
    public Resultado Porcentaje(double valor, double porcentaje){
        if(porcentaje>100){
            Resultado result = new Resultado(0, false, "El valor del porcentaje debe ser mayor a 0");
            return result; 
        }
        if(porcentaje<0){
            Resultado result = new Resultado(0, false, "El valor del porcentaje debe ser igual a 100");
            return result; 
        }
       double resultadoPorcentaje = valor*porcentaje/100;
       Resultado result = new Resultado(resultadoPorcentaje, true, "Multiplicacion realizada correctamente");
            return result; 
    }
    
    //potencia
     public Resultado Potencia(double valor, double potencia){
        if(potencia<0){
            Resultado result = new Resultado(0, false, "La potencia debe ser mayor a 0");
            return result; 
        }
        
        double resultadoPotencia = Math.pow(valor, potencia);
         Resultado result = new Resultado(resultadoPotencia, true, "Potencia realizada correctamente");
            return result; 
    }
    
     //seno
     public Resultado Seno(double valor){
         double resultadoSeno= Math.sin(valor);
         Resultado result = new Resultado(resultadoSeno, true, "El seno fue calculado correctamente");
            return result; 
     }
     
     //cos
     public Resultado Coseno(double valor){
         double resultadoCoseno= Math.cos(valor);
         Resultado result = new Resultado(resultadoCoseno, true, "El coseno fue calculado correctamente");
            return result; 
     }
     
     //tan
     public Resultado Tangente(double valor){
         if(valor == Math.PI/2||valor == 3*Math.PI/2){
            Resultado result = new Resultado(0, false, "El valor es PI/2 o 2PI/2");
            return result;
         }
         double resultadoTangente= Math.tan(valor);
         Resultado result = new Resultado(resultadoTangente, true, "El seno fue calculado correctamente");
         return result; 
     }
     
     //raiz
     public Resultado Raiz(double valor, double raiz){
         raiz = 1/raiz;
         if(raiz<0 || raiz>=1){
             Resultado result = new Resultado(0, false, "La raiz debe ser entre 0 y 1");
            return result;
         }
         double resultadoRaiz= Math.pow(valor, raiz);
         Resultado result = new Resultado(resultadoRaiz, true, "El resultado de la raiz fue calculado correctamente");
            return result;
     }
}
