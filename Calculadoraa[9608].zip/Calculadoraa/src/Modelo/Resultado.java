/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author LABSIS
 */
public class Resultado {
    public double valor;
   public boolean estadoOperacion;
   public String mensajeOperacion;
   
   
   //constructor
   
   public Resultado(double valorIn, boolean estado, String mensaje){
       valor=valorIn;
       estadoOperacion=estado;
       mensajeOperacion=mensaje;
   }
}
