/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadoraa;

import Modelo.Operaciones;
import Modelo.Resultado;
/**
 *
 * @author LABSIS
 */
public class Calculadoraa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Operaciones nuevasOperaciones = new Operaciones();
        Resultado result = nuevasOperaciones.Suma(1, 2);
        
        if(result.estadoOperacion == true){
            System.out.println("Resultado" + result.valor);
            System.out.println(result.mensajeOperacion);
        }
        else
        {
            System.out.println(result.mensajeOperacion);
        }
        
        result = nuevasOperaciones.Division(10, 0);
        if(result.estadoOperacion == true){
            System.out.println("Resultado" + result.valor);
            System.out.println(result.mensajeOperacion);
        }
        else{
            System.out.println(result.mensajeOperacion);
        }
    }
    
}
